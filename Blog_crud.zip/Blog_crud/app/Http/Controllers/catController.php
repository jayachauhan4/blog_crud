<?php

namespace App\Http\Controllers;
use App\Models\Category;
use Illuminate\Http\Request;

class catController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
//     public function index()
//     {
//         $categories = Category::all();

//         return view('categories.index', compact('categories'));
//     }

   

//     /**
//      * Show the form for creating a new resource.
//      *
//      * @return \Illuminate\Http\Response
//      */
//     public function create()
//     {
//         //
//     }

//     /**
//      * Store a newly created resource in storage.
//      *
//      * @param  \Illuminate\Http\Request  $request
//      * @return \Illuminate\Http\Response
//      */
//     public function store(Request $request)
//     {
//         //
//     }

//     /**
//      * Display the specified resource.
//      *
//      * @param  int  $id
//      * @return \Illuminate\Http\Response
//      */
//     public function show($id)
//     {
//         //
//     }

//     /**
//      * Show the form for editing the specified resource.
//      *
//      * @param  int  $id
//      * @return \Illuminate\Http\Response
//      */
//     public function edit($id)
//     {
//         $categories= Category::find($id);
//         return response()->json([
//           'status'=>200,
//           'category'=>$categories,
//         ]);
//     }

//     /**
//      * Update the specified resource in storage.
//      *
//      * @param  \Illuminate\Http\Request  $request
//      * @param  int  $id
//      * @return \Illuminate\Http\Response
//      */
//     public function update(Request $request, $id)
//     {
//         $request->validate([
//             'name' => 'required|min:3|max:255',
//             'slug' => 'required|min:3|max:255|unique:blogs',
           
//         ]);
        
  
//          $categories = Category::find($id);
         
//          if($categories)
//          {
//          $categories->name = $request->input('name');
//          $categories->slug = $request->input('slug');
         
//          $categories->update();
      
//             //Session::flash('success', 'You have successfully updated a post!');
      
//             return response()->json([
//               'status'=>200,
//               'categories'=> $categories,
//             ]);
//           }
//           else{
//             return response()->json([
//                 'status'=>404,
//                 'message'=> 'cannot update data',
//               ]);

//           }

//     /**
//      * Remove the specified resource from storage.
//      *
//      * @param  int  $id
//      * @return \Illuminate\Http\Response
//      */
//     public function destroy($id)
//     {
//         //
//     }
// }
}