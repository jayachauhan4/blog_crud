<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class blog extends Model
{
    use HasFactory;

    

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function category()
    {
        return $this->belongsTo(Category::class,'category_id');
    }
    public function cat()
    {
        return $this->belongsTo(Category::class,'category_id');
    }
    protected $table = 'blogs';
      protected $fillable = ['name', 'slug','image','description', 'category_id,user_id'];
}
