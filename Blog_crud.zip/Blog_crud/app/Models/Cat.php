<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cat extends Model
{
    use HasFactory;
    public function blog()
    {
        return $this->hasMany(Blog::class );
    }

    protected $table = 'cats';
      protected $fillable = ['slug', 'name', 'created_at'];
}
