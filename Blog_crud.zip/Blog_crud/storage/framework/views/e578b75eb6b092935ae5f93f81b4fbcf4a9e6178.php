<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Blog</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" > -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
</head>

<body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Edit Blog</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="<?php echo e(route('blogs.index')); ?>" enctype="multipart/form-data">
                        Back</a>
                </div>
            </div>
        </div>
        <div class="alert alert-success" role="alert" id="successMsg" style="display: none" >
  Blog updated successfully 
</div>
        <form action="<?php echo e(route('blogs.update',$blog->id)); ?>" id="blogeditForm" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                
                    <div class="form-group">
                        <strong>Blog Name:</strong>
                        <input type="text" name="name" id="InputName" value="<?php echo e($blog->name); ?>" class="form-control"
                            placeholder="Enter Blog name">
                            <span class="text-danger" id="nameErrorMsg"></span>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Slug:</strong>
                        <input type="text" name="slug" id="InputSlug" class="form-control" placeholder="Enter Slug"
                            value="<?php echo e($blog->slug); ?>">
                            <span class="text-danger" id="slugErrorMsg"></span>
                    </div>
                </div>
                <!-- <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                    <strong>Category:</strong>
                    <select name="category_id" class="block w-full mt-1 rounded-md" placeholder="Select Category">
                    <option 
                                        value="">Select Category</option>
                                    <option 
                                        value=""><?php echo e($blog->category->name); ?></option>
                                    
                                </select>
                                
                       
                        
                        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div> -->
                <!-- <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Image:</strong>
                        <input type="file" name="image" id="InputImage" value="<?php echo e($blog->image); ?>" class="form-control"
                            placeholder="Upload Image">
                            <span class="text-danger" id="imageErrorMsg"></span>
                    </div>
                </div> -->
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Description:</strong>
                        <input type="text" name="description" id="InputDescription" value="<?php echo e($blog->description); ?>" class="form-control"
                            placeholder="Enter Description">
                            <span class="text-danger" id="descriptionErrorMsg"></span>
                    </div>
                </div>
                <button type="submit" id="submit" class="btn btn-primary ml-3">Submit</button>
            </div>
        </form>
    </div>
</body>
<script>
     //debugger;
$(document).ready(function(){
//     $.ajaxSetup({
//      headers: {
//     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//     }
// });
$(document).on('click','.edit',function(){
    var id= $(this).val();
    console.log(id);
// $('#editCategoryModal').modal('show');

 $.ajax({
        url: "<?php echo e(route('blogs.edit',$blog->id)); ?>",
       type: "GET",
       success: function( response ) {
        console.log(response.blog);
        
        $("#name").val(response.blog.name);
       $("#slug").val(response.blog.slug);
          $("#InputImage").val(response.blog.image);
         $("#description").val(response.blog.description);
        
       }
         });
});


    $(document).on('submit','#blogeditForm',function(e){
      e.preventDefault();
      let name = $('#name').val();
    let slug = $('#slug').val();
    //let category = $('#InputCategory').val();
    let image = $('#image').val();
    let description = $('#description').val();
    //let message = $('#InputMessage').val();
       let formData = new FormData($('#blogeditForm')[0]);
       $.ajax({
       url: "<?php echo e(route('blogs.update',$blog->id)); ?>",
       headers:{
         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
          type: "POST",
          data: formData,
          contentType:false,
          processData:false,
          success: function( response ) {
       
$('#submit').html('Submit');
 $("#submit"). attr("disabled", false);
 
 setTimeout(function(){
    $('#successMsg').show();
 },10000);
 window.location.reload();
 window.location='/blogs'
 //window.location.href = {{route('blogs.index');
                    
// $('#blogeditModal').modal('hide');
// setTimeout(function(){$('#blogModal').modal('hide');},5000)
 
 document.getElementById("blogeditForm").reset(); 
 setTimeout(function(){
            $('#successMsg').hide();
            $('#msg_div').hide();
            
            },2000);
 },
 error: function(response) {
        $('#nameErrorMsg').text(response.responseJSON.errors.name);
        $('#slugErrorMsg').text(response.responseJSON.errors.slug);
        //$('#categoryErrorMsg').text(response.responseJSON.errors.category);
        $('#imageErrorMsg').text(response.responseJSON.errors.image);
        $('#descriptionErrorMsg').text(response.responseJSON.errors.description);
        //$('#messageErrorMsg').text(response.responseJSON.errors.message);
      },
});

       
   });
})




</script>
</html><?php /**PATH C:\xampp\htdocs\Blog_crud\resources\views/blogs/edit.blade.php ENDPATH**/ ?>